import sys, os
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QSize
from PySide6.QtGui import QPixmap, QPainter, QColor, QIcon, QAction
from PySide6.QtWidgets import *
from .models import Project, Slide
from .engine import render, ffprobe_duration, make_frame, SIZE
from .worker import RenderWorker

STYLE=""" 
QMainWindow{background:#11151c;color:#edf2f7}
QWidget{color:#edf2f7;font-size:13px}
QFrame#panel,QGroupBox{background:#171d26;border:1px solid #2c3542;border-radius:10px}
QGroupBox{margin-top:10px;padding:10px}
QGroupBox::title{subcontrol-origin:margin;left:10px;padding:0 6px}
QPushButton{background:#202936;border:1px solid #394554;border-radius:7px;padding:7px 11px}
QPushButton:hover{background:#2b3745}
QPushButton#primary{background:#2867a6;font-weight:bold;padding:10px}
QPushButton#danger{background:#753b42}
QListWidget{background:#151b23;border:1px solid #303946;border-radius:8px}
QListWidget::item{padding:7px}
QListWidget::item:selected{background:#285e91}
QLineEdit,QComboBox,QDoubleSpinBox,QSpinBox{background:#131921;border:1px solid #3a4553;border-radius:6px;padding:5px}
QProgressBar{border:1px solid #303946;border-radius:6px;text-align:center}
"""

class Preview(QWidget):
    def __init__(self):
        super().__init__(); self.pix=None; self.caption=""
        self.setMinimumSize(280,430)
    def set(self,path,caption=""):
        self.pix=QPixmap(path) if path else None; self.caption=caption; self.update()
    def paintEvent(self,e):
        p=QPainter(self); p.fillRect(self.rect(),QColor("#090c11"))
        if not self.pix or self.pix.isNull():
            p.setPen(QColor("#7d8998")); p.drawText(self.rect(),Qt.AlignCenter,"9:16 PREVIEW"); return
        r=self.rect().adjusted(18,18,-18,-18)
        s=self.pix.scaled(r.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation)
        p.drawPixmap(r.center().x()-s.width()//2,r.center().y()-s.height()//2,s)
        if self.caption:
            p.setPen(Qt.white); p.setBrush(QColor(0,0,0,150))
            p.drawRoundedRect(r.left()+20,r.bottom()-85,r.width()-40,55,12,12)
            p.drawText(r.left()+30,r.bottom()-50,r.width()-60,30,Qt.AlignCenter,self.caption)

class Main(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Shorts Studio v0.3"); self.resize(1280,820)
        self.setMinimumSize(1100,700); self.setStyleSheet(STYLE); self.p=Project(slides=[]); self.worker=None
        self.timer=QTimer(self); self.timer.timeout.connect(self.preview_next)
        self.preview_index=0; self.build()

    def build(self):
        root=QWidget(); self.setCentralWidget(root); v=QVBoxLayout(root); v.setContentsMargins(12,12,12,12)
        head=QHBoxLayout()
        title=QLabel("🎬  SHORTS STUDIO"); title.setStyleSheet("font-size:24px;font-weight:bold")
        sub=QLabel("  Photo • Music • Captions • 9:16")
        sub.setStyleSheet("color:#8d9bad;font-size:13px")
        head.addWidget(title); head.addWidget(sub); head.addStretch()
        for txt,fn in [("New",self.new),("Open",self.open),("Save",self.save)]:
            b=QPushButton(txt); b.clicked.connect(fn); head.addWidget(b)
        self.export=QPushButton("Export ONE MP4"); self.export.setObjectName("primary"); self.export.clicked.connect(self.export_one)
        head.addWidget(self.export); v.addLayout(head)

        sp=QSplitter(Qt.Horizontal); v.addWidget(sp,1)

        left=QFrame(); left.setObjectName("panel"); lv=QVBoxLayout(left)
        lv.addWidget(self.section("STORYBOARD"))
        self.list=QListWidget(); self.list.setIconSize(QSize(76,76)); lv.addWidget(self.list,1)
        buttons=QHBoxLayout()
        for t,f in [("+ Images",self.add),("+ Folder",self.folder),("↑",self.up),("↓",self.down),("Delete",self.delete)]:
            b=QPushButton(t); b.clicked.connect(f); buttons.addWidget(b)
        lv.addLayout(buttons)
        sp.addWidget(left)

        mid=QFrame(); mid.setObjectName("panel"); mv=QVBoxLayout(mid)
        self.preview=Preview(); mv.addWidget(self.preview,1)
        ctl=QHBoxLayout()
        self.play=QPushButton("▶ Play Preview"); self.play.clicked.connect(self.toggle_preview)
        self.stop=QPushButton("■ Stop"); self.stop.clicked.connect(self.stop_preview)
        ctl.addWidget(self.play); ctl.addWidget(self.stop); ctl.addStretch()
        mv.addLayout(ctl)
        self.status=QLabel("Add images to begin"); self.status.setAlignment(Qt.AlignCenter); mv.addWidget(self.status)
        sp.addWidget(mid)

        right=QFrame(); right.setObjectName("panel"); rv=QVBoxLayout(right)
        rv.addWidget(self.section("PROJECT"))
        timing=QGroupBox("Timeline"); tf=QFormLayout(timing)
        self.duration=QDoubleSpinBox(); self.duration.setRange(.5,120); self.duration.setValue(4); self.duration.setSuffix(" s")
        self.trans=QComboBox(); self.trans.addItems(["Crossfade","None"])
        self.transdur=QDoubleSpinBox(); self.transdur.setRange(0,3); self.transdur.setValue(.6); self.transdur.setSuffix(" s")
        self.fit=QCheckBox("Fit all images to music")
        tf.addRow("Default duration",self.duration); tf.addRow("Transition",self.trans); tf.addRow("Crossfade",self.transdur); tf.addRow(self.fit)
        rv.addWidget(timing)
        music=QGroupBox("Music"); mf=QVBoxLayout(music)
        self.music=QLabel("No audio selected"); self.choose=QPushButton("Choose MP3 / Audio"); self.choose.clicked.connect(self.audio)
        self.musicinfo=QLabel(""); mf.addWidget(self.music); mf.addWidget(self.choose); mf.addWidget(self.musicinfo); rv.addWidget(music)
        edit=QGroupBox("Selected Image"); ef=QFormLayout(edit)
        self.zoom=self.spin(.5,3,1,.05); self.bright=self.spin(.2,2,1,.05); self.contrast=self.spin(.2,2,1,.05); self.sat=self.spin(0,2,1,.05); self.warm=self.spin(-2,2,0,.1)
        self.cap=QLineEdit(); self.cap.setPlaceholderText("Caption for this image")
        self.effect=QComboBox(); self.effect.addItems(["None","Ken Burns","Soft Blur"])
        for n,w in [("Zoom",self.zoom),("Brightness",self.bright),("Contrast",self.contrast),("Saturation",self.sat),("Warmth",self.warm),("Caption",self.cap),("Effect",self.effect)]: ef.addRow(n,w)
        ap=QPushButton("Apply to Selected"); ap.clicked.connect(self.apply); ef.addRow(ap); rv.addWidget(edit)
        glob=QGroupBox("Global Caption"); gl=QVBoxLayout(glob); self.gcap=QLineEdit(); self.gcap.setPlaceholderText("Used when an image has no caption"); gl.addWidget(self.gcap); rv.addWidget(glob)
        out=QGroupBox("Output"); of=QFormLayout(out); self.fps=QSpinBox(); self.fps.setRange(12,60); self.fps.setValue(24); of.addRow("FPS",self.fps); of.addRow("Size",QLabel("1080 × 1920")); rv.addWidget(out)
        rv.addStretch(); sp.addWidget(right); sp.setSizes([330,620,410])

        self.list.currentRowChanged.connect(self.select)
        self.fit.stateChanged.connect(lambda x:self.update_music())
        self.trans.currentTextChanged.connect(lambda x:setattr(self.p,"transition",x))
        self.transdur.valueChanged.connect(lambda x:setattr(self.p,"transition_duration",x))
        self.duration.valueChanged.connect(lambda x:self.set_default(x))

    def section(self,t):
        x=QLabel(t); x.setStyleSheet("font-size:11px;font-weight:bold;color:#8fa1b5;letter-spacing:1px"); return x
    def spin(self,a,b,c,s):
        x=QDoubleSpinBox(); x.setRange(a,b); x.setValue(c); x.setSingleStep(s); return x
    def add(self):
        ps,_=QFileDialog.getOpenFileNames(self,"Add Images","","Images (*.jpg *.jpeg *.png *.webp *.bmp)")
        for p in ps:self.add_slide(p)
    def folder(self):
        d=QFileDialog.getExistingDirectory(self,"Image Folder")
        if d:
            for p in sorted(Path(d).iterdir()):
                if p.suffix.lower() in {".jpg",".jpeg",".png",".webp",".bmp"}: self.add_slide(str(p))
    def add_slide(self,path):
        self.p.slides.append(Slide(path,duration=self.duration.value()))
        it=QListWidgetItem(Path(path).name); it.setIcon(QIcon(QPixmap(path).scaled(76,76,Qt.KeepAspectRatio,Qt.SmoothTransformation))); self.list.addItem(it)
        self.list.setCurrentRow(self.list.count()-1); self.update_music()
    def select(self,r):
        if 0<=r<len(self.p.slides):
            s=self.p.slides[r]; self.preview.set(s.path,s.caption or self.p.global_caption)
            self.zoom.setValue(s.zoom); self.bright.setValue(s.brightness); self.contrast.setValue(s.contrast); self.sat.setValue(s.saturation); self.warm.setValue(s.warmth); self.cap.setText(s.caption); self.effect.setCurrentText(s.effect)
            self.status.setText(f"{r+1} / {len(self.p.slides)}   •   {Path(s.path).name}   •   {s.duration:.1f}s")
    def apply(self):
        r=self.list.currentRow()
        if r<0:return
        s=self.p.slides[r]; s.zoom=self.zoom.value(); s.brightness=self.bright.value(); s.contrast=self.contrast.value(); s.saturation=self.sat.value(); s.warmth=self.warm.value(); s.caption=self.cap.text(); s.effect=self.effect.currentText(); self.select(r)
    def set_default(self,x): pass
    def audio(self):
        p,_=QFileDialog.getOpenFileName(self,"Choose Music","","Audio (*.mp3 *.wav *.m4a *.aac *.ogg)")
        if p:self.p.audio=p; self.music.setText(Path(p).name); self.update_music()
    def update_music(self):
        if self.p.audio:
            d=ffprobe_duration(self.p.audio); each=d/len(self.p.slides) if self.p.slides else 0
            self.musicinfo.setText(f"{d:.1f}s total  •  {each:.1f}s/image when fitted")
        else:self.musicinfo.setText("")
    def up(self):
        r=self.list.currentRow()
        if r>0:self.swap(r,r-1)
    def down(self):
        r=self.list.currentRow()
        if 0<=r<len(self.p.slides)-1:self.swap(r,r+1)
    def swap(self,a,b):
        self.p.slides[a],self.p.slides[b]=self.p.slides[b],self.p.slides[a]
        it=self.list.takeItem(a); self.list.insertItem(b,it); self.list.setCurrentRow(b)
    def delete(self):
        r=self.list.currentRow()
        if r>=0:self.p.slides.pop(r); self.list.takeItem(r); self.update_music()
    def toggle_preview(self):
        if not self.p.slides:return
        if self.timer.isActive(): self.timer.stop(); self.play.setText("▶ Play Preview")
        else:
            self.preview_index=self.list.currentRow() if self.list.currentRow()>=0 else 0
            self.timer.start(max(500,int(self.p.slides[self.preview_index].duration*1000)))
            self.show_preview_index()
            self.play.setText("❚❚ Pause")
    def stop_preview(self):
        self.timer.stop(); self.play.setText("▶ Play Preview"); self.preview_index=0
        if self.p.slides:self.show_preview_index()
    def preview_next(self):
        if not self.p.slides:return
        self.preview_index=(self.preview_index+1)%len(self.p.slides); self.show_preview_index()
        self.timer.start(max(500,int(self.p.slides[self.preview_index].duration*1000)))
    def show_preview_index(self):
        self.list.setCurrentRow(self.preview_index); s=self.p.slides[self.preview_index]; self.preview.set(s.path,s.caption or self.p.global_caption)
    def new(self):
        self.timer.stop(); self.p=Project(slides=[]); self.list.clear(); self.preview.set(None); self.music.setText("No audio selected"); self.status.setText("New project")
    def save(self):
        p,_=QFileDialog.getSaveFileName(self,"Save Project","","Shorts Project (*.ssp)")
        if p:
            if not p.endswith(".ssp"):p+=".ssp"
            self.p.global_caption=self.gcap.text(); self.p.fit_music=self.fit.isChecked(); self.p.save(p)
    def open(self):
        p,_=QFileDialog.getOpenFileName(self,"Open Project","","Shorts Project (*.ssp)")
        if not p:return
        try:
            self.p=Project.load(p); self.list.clear()
            for s in self.p.slides:
                it=QListWidgetItem(Path(s.path).name); it.setIcon(QIcon(QPixmap(s.path).scaled(76,76,Qt.KeepAspectRatio,Qt.SmoothTransformation))); self.list.addItem(it)
            self.fit.setChecked(self.p.fit_music); self.trans.setCurrentText(self.p.transition); self.transdur.setValue(self.p.transition_duration); self.gcap.setText(self.p.global_caption)
            self.music.setText(Path(self.p.audio).name if self.p.audio else "No audio selected"); self.update_music()
            if self.p.slides:self.list.setCurrentRow(0)
        except Exception as e:QMessageBox.critical(self,"Open failed",str(e))
    def export_one(self):
        if not self.p.slides: QMessageBox.warning(self,"No images","Add images first."); return
        out,_=QFileDialog.getSaveFileName(self,"Export ONE Combined MP4","","MP4 Video (*.mp4)")
        if not out:return
        if not out.lower().endswith(".mp4"):out+=".mp4"
        self.p.global_caption=self.gcap.text(); self.p.fit_music=self.fit.isChecked(); self.p.fps=self.fps.value()
        self.export.setEnabled(False); self.status.setText("Rendering one combined MP4…")
        self.worker=RenderWorker(lambda cb,cc:render(self.p,out,cb,cc),out)
        self.worker.progress.connect(lambda n:self.status.setText(f"Rendering combined MP4… {n}%"))
        self.worker.success.connect(lambda p:(self.export.setEnabled(True),QMessageBox.information(self,"Export complete",f"Created:\n{p}"),self.status.setText(Path(p).name)))
        self.worker.error.connect(lambda e:(self.export.setEnabled(True),QMessageBox.critical(self,"Export failed",e)))
        self.worker.start()

def main():
    app=QApplication(sys.argv); app.setApplicationName("Shorts Studio"); w=Main(); w.show(); sys.exit(app.exec())
