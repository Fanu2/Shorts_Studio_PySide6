
import sys, math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QColor, QImage, QPixmap
from PySide6.QtWidgets import *

SHAPES=["Circle","Ellipse","Rounded Rectangle","Triangle","Diamond","Pentagon","Hexagon","Octagon",
        "Star 5","Star 6","Star 8","Heart","Shield","Cloud","Speech Bubble","Cross"]
SIZES={"Original":None,"128 × 128":128,"256 × 256":256,"512 × 512":512,"1024 × 1024":1024}

def poly(cx,cy,r,n,rot=-math.pi/2):
    return [(cx+r*math.cos(rot+2*math.pi*i/n),cy+r*math.sin(rot+2*math.pi*i/n)) for i in range(n)]
def star(cx,cy,ro,ri,n):
    return [(cx+(ro if i%2==0 else ri)*math.cos(-math.pi/2+math.pi*i/n),
             cy+(ro if i%2==0 else ri)*math.sin(-math.pi/2+math.pi*i/n)) for i in range(2*n)]

def mask_for(size,shape,radius):
    w,h=size; m=Image.new("L",size,0); d=ImageDraw.Draw(m); p=4
    cx,cy=w/2,h/2; r=min(w,h)/2-p; box=(p,p,w-p-1,h-p-1)
    if shape in ("Circle","Ellipse"): d.ellipse(box,fill=255)
    elif shape=="Rounded Rectangle": d.rounded_rectangle(box,radius=min(radius,min(w,h)//2),fill=255)
    elif shape=="Triangle": d.polygon(poly(cx,cy,r,3),fill=255)
    elif shape=="Diamond": d.polygon([(cx,p),(w-p,cy),(cx,h-p),(p,cy)],fill=255)
    elif shape in ("Pentagon","Hexagon","Octagon"): d.polygon(poly(cx,cy,r,{"Pentagon":5,"Hexagon":6,"Octagon":8}[shape]),fill=255)
    elif shape.startswith("Star"):
        n=int(shape.split()[1]); d.polygon(star(cx,cy,r,r*.46,n),fill=255)
    elif shape=="Heart":
        pts=[]
        for i in range(361):
            t=math.radians(i); x=16*math.sin(t)**3
            y=13*math.cos(t)-5*math.cos(2*t)-2*math.cos(3*t)-math.cos(4*t)
            pts.append((cx+x*r/17,cy-y*r/17))
        d.polygon(pts,fill=255)
    elif shape=="Shield":
        d.polygon([(p,p),(w-p,p),(w-p*.8,cy),(cx,h-p),(w*.2,h-p*.3),(p*.8,cy)],fill=255)
    elif shape=="Cloud":
        d.ellipse((p,cy-r*.15,cx,cy+r*.55),fill=255); d.ellipse((cx-r*.2,cy-r*.5,w-p,cy+r*.35),fill=255)
        d.rounded_rectangle((p,cy+r*.05,w-p,h-p),radius=int(r*.2),fill=255)
    elif shape=="Speech Bubble":
        d.rounded_rectangle(box,radius=int(r*.18),fill=255)
        d.polygon([(w*.28,h*.72),(w*.20,h-p),(w*.46,h*.72)],fill=255)
    elif shape=="Cross":
        t=int(min(w,h)*.3); d.rectangle((cx-t/2,p,cx+t/2,h-p),fill=255); d.rectangle((p,cy-t/2,w-p,cy+t/2),fill=255)
    return m

def qimage(im):
    im=im.convert("RGBA"); return QImage(im.tobytes("raw","RGBA"),im.width,im.height,im.width*4,QImage.Format_RGBA8888).copy()

class Canvas(QLabel):
    def __init__(self,owner):
        super().__init__(); self.owner=owner; self.setAlignment(Qt.AlignCenter); self.setMinimumSize(480,480)
        self.setStyleSheet("background:#171a21;border:1px solid #343a46;border-radius:12px;color:#9aa4b2;font-size:16px;")
        self.setText("Open an image to begin"); self.drag=None
    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton and self.owner.image: self.drag=e.position()
    def mouseMoveEvent(self,e):
        if self.drag is not None:
            d=e.position()-self.drag; self.drag=e.position()
            self.owner.x.setValue(self.owner.x.value()+round(d.x())); self.owner.y.setValue(self.owner.y.value()+round(d.y()))
    def mouseReleaseEvent(self,e): self.drag=None
    def wheelEvent(self,e):
        if self.owner.image: self.owner.zoom.setValue(self.owner.zoom.value()+(5 if e.angleDelta().y()>0 else -5))

class Window(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Image Shape Studio v0.1"); self.resize(1250,820)
        self.image=None; self.path=None; self.bg=(255,255,255,255); self.build()
    def build(self):
        self.setStyleSheet("""QMainWindow{background:#101218;color:#e8edf5} QWidget{color:#e8edf5}
        QGroupBox{border:1px solid #303642;border-radius:10px;margin-top:12px;padding:12px}
        QGroupBox::title{left:12px;padding:0 6px;color:#8fb7ff}
        QPushButton{background:#252b36;border:1px solid #3b4351;border-radius:7px;padding:8px}
        QPushButton:hover{background:#303846} QComboBox,QSpinBox,QSlider{background:#1b1f27}
        QLabel#title{font-size:21px;font-weight:700} QLabel#sub{color:#8f99a8}""")
        c=QWidget(); self.setCentralWidget(c); main=QVBoxLayout(c)
        h=QHBoxLayout(); v=QVBoxLayout(); a=QLabel("Image Shape Studio"); a.setObjectName("title")
        b=QLabel("Shape masking • positioning • styling • batch export"); b.setObjectName("sub")
        v.addWidget(a); v.addWidget(b); h.addLayout(v); h.addStretch()
        for text,fn in [("Open Image",self.open),("Batch Convert",self.batch)]:
            q=QPushButton(text); q.clicked.connect(fn); h.addWidget(q)
        main.addLayout(h); sp=QSplitter(Qt.Horizontal); main.addWidget(sp,1)

        left=QWidget(); L=QVBoxLayout(left)
        g=QGroupBox("Shape"); f=QFormLayout(g)
        self.shape=QComboBox(); self.shape.addItems(SHAPES); self.shape.currentTextChanged.connect(self.refresh)
        self.size=QComboBox(); self.size.addItems(SIZES); self.size.currentTextChanged.connect(self.refresh)
        self.corner=QSpinBox(); self.corner.setRange(0,500); self.corner.setValue(50); self.corner.valueChanged.connect(self.refresh)
        f.addRow("Shape",self.shape); f.addRow("Output",self.size); f.addRow("Corner radius",self.corner); L.addWidget(g)

        g=QGroupBox("Image"); f=QFormLayout(g)
        self.zoom=QSlider(Qt.Horizontal); self.zoom.setRange(20,300); self.zoom.setValue(100); self.zoom.valueChanged.connect(self.refresh)
        self.x=QSpinBox(); self.x.setRange(-2000,2000); self.x.valueChanged.connect(self.refresh)
        self.y=QSpinBox(); self.y.setRange(-2000,2000); self.y.valueChanged.connect(self.refresh)
        self.rot=QSpinBox(); self.rot.setRange(-180,180); self.rot.valueChanged.connect(self.refresh)
        for lab,w in [("Zoom",self.zoom),("Position X",self.x),("Position Y",self.y),("Rotation",self.rot)]: f.addRow(lab,w)
        q=QPushButton("Reset"); q.clicked.connect(self.reset); f.addRow(q); L.addWidget(g)

        g=QGroupBox("Border & Shadow"); f=QFormLayout(g)
        self.border=QCheckBox("Enable border"); self.border.setChecked(True); self.border.stateChanged.connect(self.refresh)
        self.bw=QSpinBox(); self.bw.setRange(0,50); self.bw.setValue(4); self.bw.valueChanged.connect(self.refresh)
        self.shadow=QCheckBox("Enable soft shadow"); self.shadow.stateChanged.connect(self.refresh)
        self.blur=QSpinBox(); self.blur.setRange(1,50); self.blur.setValue(12); self.blur.valueChanged.connect(self.refresh)
        f.addRow(self.border); f.addRow("Border width",self.bw); f.addRow(self.shadow); f.addRow("Shadow blur",self.blur); L.addWidget(g)

        g=QGroupBox("Background / Export"); f=QFormLayout(g)
        self.trans=QCheckBox("Transparent background"); self.trans.setChecked(True); self.trans.stateChanged.connect(self.refresh)
        f.addRow(self.trans)
        q=QPushButton("Choose background"); q.clicked.connect(self.choose_bg); f.addRow(q)
        for text,fmt in [("Export PNG","PNG"),("Export JPEG","JPEG"),("Export WEBP","WEBP")]:
            q=QPushButton(text); q.clicked.connect(lambda _,z=fmt:self.export(z)); f.addRow(q)
        L.addWidget(g); L.addStretch(); sp.addWidget(left)

        right=QWidget(); R=QVBoxLayout(right); self.canvas=Canvas(self); R.addWidget(self.canvas,1)
        z=QLabel("Drag to reposition • Mouse wheel to zoom • Transparent PNG is ideal for shaped images")
        z.setStyleSheet("color:#8f99a8;padding:6px"); R.addWidget(z); sp.addWidget(right); sp.setSizes([370,820])
    def open(self):
        p,_=QFileDialog.getOpenFileName(self,"Open Image","","Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        if p:
            try: self.image=Image.open(p).convert("RGBA"); self.path=Path(p); self.reset(); self.refresh()
            except Exception as e: QMessageBox.critical(self,"Open failed",str(e))
    def reset(self): self.zoom.setValue(100); self.x.setValue(0); self.y.setValue(0); self.rot.setValue(0)
    def choose_bg(self):
        c=QColorDialog.getColor(QColor(*self.bg[:3]),self)
        if c.isValid(): self.bg=(c.red(),c.green(),c.blue(),255); self.trans.setChecked(False); self.refresh()
    def render(self,n=700):
        if not self.image:return None
        c=Image.new("RGBA",(n,n),self.bg if not self.trans.isChecked() else (0,0,0,0))
        im=self.image.copy(); s=self.zoom.value()/100; im=im.resize((max(1,int(im.width*s)),max(1,int(im.height*s))),Image.Resampling.LANCZOS)
        if self.rot.value(): im=im.rotate(self.rot.value(),expand=True,resample=Image.Resampling.BICUBIC)
        c.alpha_composite(im,(int((n-im.width)/2+self.x.value()),int((n-im.height)/2+self.y.value())))
        m=mask_for((n,n),self.shape.currentText(),self.corner.value())
        if self.shadow.isChecked():
            sh=Image.new("RGBA",(n,n),(0,0,0,0)); sm=m.filter(ImageFilter.GaussianBlur(self.blur.value())); sh.paste((0,0,0,120),(0,0,n,n),sm); c=Image.alpha_composite(sh,c)
        c.putalpha(Image.composite(c.getchannel("A"),Image.new("L",(n,n),0),m))
        if self.border.isChecked() and self.bw.value():
            lay=Image.new("RGBA",(n,n),(0,0,0,0)); d=ImageDraw.Draw(lay); w=self.bw.value(); col=(255,255,255,255); sh=self.shape.currentText()
            if sh in ("Circle","Ellipse"): d.ellipse((w//2,w//2,n-w//2-1,n-w//2-1),outline=col,width=w)
            elif sh=="Rounded Rectangle": d.rounded_rectangle((w//2,w//2,n-w//2-1,n-w//2-1),radius=min(self.corner.value(),n//2),outline=col,width=w)
            elif sh=="Diamond": pts=[(n/2,w),(n-w,n/2),(n/2,n-w),(w,n/2)]; d.line(pts+[pts[0]],fill=col,width=w,joint="curve")
            elif sh=="Triangle": pts=poly(n/2,n/2,n/2-w,3); d.line(pts+[pts[0]],fill=col,width=w,joint="curve")
            elif sh in ("Pentagon","Hexagon","Octagon"): pts=poly(n/2,n/2,n/2-w,{"Pentagon":5,"Hexagon":6,"Octagon":8}[sh]); d.line(pts+[pts[0]],fill=col,width=w,joint="curve")
            elif sh.startswith("Star"): pts=star(n/2,n/2,n/2-w,(n/2-w)*.46,int(sh.split()[1])); d.line(pts+[pts[0]],fill=col,width=w,joint="curve")
            lay.putalpha(Image.composite(lay.getchannel("A"),Image.new("L",(n,n),0),m)); c=Image.alpha_composite(c,lay)
        return c
    def refresh(self):
        if not self.image:self.canvas.setText("Open an image to begin"); return
        p=QPixmap.fromImage(qimage(self.render())); self.canvas.setPixmap(p.scaled(self.canvas.size()-QSize(20,20),Qt.KeepAspectRatio,Qt.SmoothTransformation))
    def resizeEvent(self,e): super().resizeEvent(e); self.refresh()
    def export(self,fmt):
        if not self.image: QMessageBox.information(self,"No image","Open an image first."); return
        ext={"PNG":"png","JPEG":"jpg","WEBP":"webp"}[fmt]
        p,_=QFileDialog.getSaveFileName(self,"Export",(self.path.stem if self.path else "image")+"_"+self.shape.currentText().lower().replace(" ","_")+"."+ext,f"{fmt} (*.{ext})")
        if not p:return
        n=SIZES[self.size.currentText()] or max(self.image.size)
        im=self.render(n)
        if fmt=="JPEG":
            bg=Image.new("RGB",im.size,(255,255,255)); bg.paste(im,mask=im.getchannel("A")); im=bg
        im.save(p,format=fmt,quality=95); QMessageBox.information(self,"Export complete",f"Saved:\\n{p}")
    def batch(self):
        files,_=QFileDialog.getOpenFileNames(self,"Select images","","Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        if not files:return
        out=QFileDialog.getExistingDirectory(self,"Choose output folder")
        if not out:return
        n=SIZES[self.size.currentText()] or 1024; count=0
        try:
            for fp in files:
                self.image=Image.open(fp).convert("RGBA"); self.path=Path(fp)
                self.render(n).save(Path(out)/(self.path.stem+"_"+self.shape.currentText().lower().replace(" ","_")+".png"),"PNG"); count+=1
            self.refresh(); QMessageBox.information(self,"Batch complete",f"Converted {count} image(s).")
        except Exception as e: QMessageBox.critical(self,"Batch failed",str(e))

def main():
    app=QApplication(sys.argv); w=Window(); w.show(); sys.exit(app.exec())
