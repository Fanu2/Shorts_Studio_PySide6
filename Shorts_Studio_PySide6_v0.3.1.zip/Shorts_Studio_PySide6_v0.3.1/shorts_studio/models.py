from dataclasses import dataclass, asdict
from pathlib import Path
import json

@dataclass
class Slide:
    path: str
    duration: float = 4.0
    zoom: float = 1.0
    brightness: float = 1.0
    contrast: float = 1.0
    saturation: float = 1.0
    warmth: float = 0.0
    caption: str = ""
    effect: str = "None"

@dataclass
class Project:
    slides: list
    audio: str = ""
    fit_music: bool = False
    transition: str = "Crossfade"
    transition_duration: float = 0.6
    global_caption: str = ""
    fps: int = 24
    width: int = 1080
    height: int = 1920

    def save(self, path):
        d = asdict(self)
        d["slides"] = [asdict(s) for s in self.slides]
        Path(path).write_text(json.dumps(d, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path):
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        d["slides"] = [Slide(**x) for x in d.get("slides", [])]
        return cls(**d)
