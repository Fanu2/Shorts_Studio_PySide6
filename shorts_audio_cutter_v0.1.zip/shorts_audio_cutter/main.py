import os
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np
from PySide6.QtCore import Qt, QUrl, QRectF, QPointF
from PySide6.QtGui import QPainter, QPen, QBrush
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QHBoxLayout, QLabel, QMainWindow,
    QMessageBox, QPushButton, QDoubleSpinBox, QVBoxLayout, QWidget
)


AUDIO_EXTENSIONS = "*.mp3 *.wav *.m4a *.aac *.flac *.ogg *.opus *.mp4 *.mkv *.webm"


def format_time(seconds: float) -> str:
    seconds = max(0.0, seconds)
    m = int(seconds // 60)
    s = seconds - m * 60
    return f"{m:02d}:{s:06.3f}"


class WaveformWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(180)
        self.samples = np.array([])
        self.duration = 1.0
        self.start = 0.0
        self.end = 0.0
        self.cursor = 0.0

    def set_data(self, samples, duration):
        self.samples = samples
        self.duration = max(duration, 0.001)
        self.start = 0.0
        self.end = duration
        self.update()

    def set_selection(self, start, end):
        self.start, self.end = start, end
        self.update()

    def set_cursor(self, position):
        self.cursor = position
        self.update()

    def mousePressEvent(self, event):
        if self.duration <= 0:
            return
        x = max(0, min(self.width(), event.position().x()))
        pos = x / max(1, self.width()) * self.duration
        if abs(pos - self.start) < abs(pos - self.end):
            self.start = pos
        else:
            self.end = pos
        if self.start > self.end:
            self.start, self.end = self.end, self.start
        self.update()
        self.parent().selection_from_waveform(self.start, self.end)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = self.rect().adjusted(8, 12, -8, -20)

        p.fillRect(self.rect(), Qt.GlobalColor.black)

        if len(self.samples):
            mid = rect.center().y()
            half = rect.height() * 0.42
            pen = QPen(Qt.GlobalColor.lightGray, 1)
            p.setPen(pen)

            n = len(self.samples)
            for x in range(rect.width()):
                i = int(x / max(1, rect.width()) * n)
                if i >= n:
                    i = n - 1
                amp = float(abs(self.samples[i]))
                y = amp * half
                p.drawLine(
                    QPointF(rect.left() + x, mid - y),
                    QPointF(rect.left() + x, mid + y),
                )

            sx = rect.left() + self.start / self.duration * rect.width()
            ex = rect.left() + self.end / self.duration * rect.width()
            p.fillRect(QRectF(sx, rect.top(), ex - sx, rect.height()),
                       QBrush(Qt.GlobalColor.darkGray))

            # redraw waveform over selection
            p.setPen(QPen(Qt.GlobalColor.white, 1))
            for x in range(max(0, int(sx-rect.left())), min(rect.width(), int(ex-rect.left()+1))):
                i = int(x / max(1, rect.width()) * n)
                if i >= n:
                    i = n - 1
                amp = float(abs(self.samples[i]))
                y = amp * half
                xx = rect.left() + x
                p.drawLine(QPointF(xx, mid-y), QPointF(xx, mid+y))

            for x in (sx, ex):
                p.setPen(QPen(Qt.GlobalColor.red, 2))
                p.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))

            cx = rect.left() + self.cursor / self.duration * rect.width()
            p.setPen(QPen(Qt.GlobalColor.yellow, 2))
            p.drawLine(QPointF(cx, rect.top()), QPointF(cx, rect.bottom()))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Shorts Audio Cutter — V0.1")
        self.resize(900, 560)

        self.input_file = None
        self.duration = 0.0
        self.temp_wav = None

        self.player = QMediaPlayer(self)
        self.audio_output = QAudioOutput(self)
        self.audio_output.setVolume(1.0)
        self.player.setAudioOutput(self.audio_output)
        self.player.positionChanged.connect(self.position_changed)
        self.player.mediaStatusChanged.connect(self.media_status_changed)

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        top = QHBoxLayout()
        self.open_btn = QPushButton("Open Audio / Video")
        self.open_btn.clicked.connect(self.open_file)
        top.addWidget(self.open_btn)
        self.file_label = QLabel("No file loaded")
        top.addWidget(self.file_label, 1)
        layout.addLayout(top)

        self.waveform = WaveformWidget()
        layout.addWidget(self.waveform)

        times = QHBoxLayout()
        times.addWidget(QLabel("Start:"))
        self.start_spin = self.time_spin()
        times.addWidget(self.start_spin)
        times.addSpacing(20)
        times.addWidget(QLabel("End:"))
        self.end_spin = self.time_spin()
        times.addWidget(self.end_spin)
        times.addSpacing(20)
        self.duration_label = QLabel("Duration: 00:00.000")
        times.addWidget(self.duration_label)
        layout.addLayout(times)

        controls = QHBoxLayout()
        self.play_btn = QPushButton("▶ Play Selection")
        self.play_btn.clicked.connect(self.play_selection)
        controls.addWidget(self.play_btn)

        stop_btn = QPushButton("■ Stop")
        stop_btn.clicked.connect(self.player.stop)
        controls.addWidget(stop_btn)

        for seconds in (15, 30, 60, 90):
            b = QPushButton(f"{seconds}s")
            b.clicked.connect(lambda _, s=seconds: self.quick_select(s))
            controls.addWidget(b)

        controls.addStretch()
        layout.addLayout(controls)

        export = QHBoxLayout()
        export.addWidget(QLabel("Format:"))
        self.format_combo = QComboBox()
        self.format_combo.addItems(["MP3", "WAV"])
        export.addWidget(self.format_combo)

        self.export_btn = QPushButton("✂ Export Short")
        self.export_btn.clicked.connect(self.export_clip)
        export.addWidget(self.export_btn)
        layout.addLayout(export)

        self.statusBar().showMessage("Ready — FFmpeg is required.")

        self.start_spin.valueChanged.connect(self.spin_changed)
        self.end_spin.valueChanged.connect(self.spin_changed)

    def time_spin(self):
        w = QDoubleSpinBox()
        w.setDecimals(3)
        w.setRange(0, 999999)
        w.setSingleStep(0.1)
        w.setSuffix(" sec")
        return w

    def ffmpeg_available(self):
        return shutil.which("ffmpeg") is not None

    def open_file(self):
        if not self.ffmpeg_available():
            QMessageBox.critical(self, "FFmpeg Missing",
                                 "FFmpeg was not found on PATH.\nInstall FFmpeg and try again.")
            return

        path, _ = QFileDialog.getOpenFileName(
            self, "Open Audio or Video", "", f"Media Files ({AUDIO_EXTENSIONS})"
        )
        if not path:
            return

        self.input_file = path
        self.file_label.setText(Path(path).name)
        self.statusBar().showMessage("Reading media…")

        try:
            duration = self.probe_duration(path)
            samples = self.make_waveform(path)
        except Exception as e:
            QMessageBox.critical(self, "Open Error", str(e))
            return

        self.duration = duration
        self.start_spin.setRange(0, duration)
        self.end_spin.setRange(0, duration)
        self.start_spin.setValue(0)
        self.end_spin.setValue(duration)
        self.duration_label.setText(f"Duration: {format_time(duration)}")
        self.waveform.set_data(samples, duration)
        self.statusBar().showMessage("Ready.")

        self.player.setSource(QUrl.fromLocalFile(path))

    def probe_duration(self, path):
        cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "default=noprint_wrappers=1:nokey=1", path]
        if not shutil.which("ffprobe"):
            # ffmpeg itself can provide duration through stderr, but ffprobe is normally bundled.
            raise RuntimeError("ffprobe was not found. Install the FFmpeg package containing ffprobe.")
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return float(result.stdout.strip())

    def make_waveform(self, path):
        # Low-resolution mono PCM for a responsive overview.
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            temp = f.name
        try:
            cmd = ["ffmpeg", "-y", "-i", path, "-vn", "-ac", "1",
                   "-ar", "8000", "-f", "wav", temp]
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                raise RuntimeError(result.stderr[-1200:])

            with wave.open(temp, "rb") as wf:
                frames = wf.readframes(wf.getnframes())
                data = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0

            # Reduce to at most ~2500 points using peak-per-bin.
            target = min(2500, max(100, len(data) // 100))
            if len(data) > target:
                bins = np.array_split(np.abs(data), target)
                data = np.array([b.max() for b in bins], dtype=np.float32)
            else:
                data = np.abs(data)
            return data
        finally:
            try:
                os.remove(temp)
            except OSError:
                pass

    def spin_changed(self):
        if self.duration <= 0:
            return
        start = min(self.start_spin.value(), self.end_spin.value())
        end = max(self.start_spin.value(), self.end_spin.value())
        self.waveform.set_selection(start, end)
        self.duration_label.setText(f"Duration: {format_time(end-start)}")

    def selection_from_waveform(self, start, end):
        self.start_spin.blockSignals(True)
        self.end_spin.blockSignals(True)
        self.start_spin.setValue(start)
        self.end_spin.setValue(end)
        self.start_spin.blockSignals(False)
        self.end_spin.blockSignals(False)
        self.duration_label.setText(f"Duration: {format_time(end-start)}")

    def quick_select(self, seconds):
        if not self.input_file:
            return
        end = min(self.duration, self.start_spin.value() + seconds)
        self.end_spin.setValue(end)

    def play_selection(self):
        if not self.input_file:
            return
        self.player.setPosition(int(self.start_spin.value() * 1000))
        self.player.play()

    def position_changed(self, position):
        sec = position / 1000.0
        self.waveform.set_cursor(sec)
        if sec >= self.end_spin.value() and self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
            self.player.setPosition(int(self.start_spin.value() * 1000))

    def media_status_changed(self, status):
        pass

    def export_clip(self):
        if not self.input_file:
            QMessageBox.warning(self, "No File", "Open an audio or video file first.")
            return

        start = min(self.start_spin.value(), self.end_spin.value())
        end = max(self.start_spin.value(), self.end_spin.value())
        if end <= start:
            QMessageBox.warning(self, "Invalid Selection", "End time must be after start time.")
            return

        fmt = self.format_combo.currentText().lower()
        suffix = ".mp3" if fmt == "mp3" else ".wav"
        out, _ = QFileDialog.getSaveFileName(
            self, "Export Short", str(Path(self.input_file).with_suffix(suffix)),
            f"{fmt.upper()} (*{suffix})"
        )
        if not out:
            return

        self.statusBar().showMessage("Exporting…")
        QApplication.processEvents()

        if fmt == "mp3":
            cmd = ["ffmpeg", "-y", "-ss", str(start), "-i", self.input_file,
                   "-t", str(end-start), "-vn", "-codec:a", "libmp3lame",
                   "-b:a", "192k", out]
        else:
            cmd = ["ffmpeg", "-y", "-ss", str(start), "-i", self.input_file,
                   "-t", str(end-start), "-vn", "-codec:a", "pcm_s16le", out]

        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            self.statusBar().showMessage("Export failed.")
            QMessageBox.critical(self, "Export Error", result.stderr[-2000:])
            return

        self.statusBar().showMessage(f"Exported: {out}")
        QMessageBox.information(self, "Export Complete",
                                f"Short exported successfully.\n\n{out}")

    def closeEvent(self, event):
        self.player.stop()
        super().closeEvent(event)


if __name__ == "__main__":
    app = QApplication([])
    app.setApplicationName("Shorts Audio Cutter")
    window = MainWindow()
    window.show()
    app.exec()
