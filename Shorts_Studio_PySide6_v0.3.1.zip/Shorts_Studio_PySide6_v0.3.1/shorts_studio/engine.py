from pathlib import Path
import subprocess, tempfile, os, math, re
import numpy as np
from PIL import Image, ImageEnhance, ImageDraw, ImageFont, ImageFilter
import imageio.v2 as imageio
import imageio_ffmpeg

SIZE = (1080, 1920)

def ffprobe_duration(path):
    """Return media duration using the bundled FFmpeg executable.

    imageio-ffmpeg does not provide get_ffprobe_exe() on Windows, so
    use FFmpeg itself and parse the Duration line from stderr.
    """
    if not path or not Path(path).exists():
        return 0.0
    exe = imageio_ffmpeg.get_ffmpeg_exe()
    p = subprocess.run(
        [exe, "-i", str(path), "-f", "null", "-"],
        capture_output=True, text=True
    )
    text = (p.stderr or "") + (p.stdout or "")
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
    if not m:
        return 0.0
    h, minute, sec = m.groups()
    return int(h) * 3600 + int(minute) * 60 + float(sec)

def make_frame(path, size=SIZE, zoom=1.0, brightness=1.0, contrast=1.0,
               saturation=1.0, warmth=0.0):
    im = Image.open(path).convert("RGB")
    im = ImageEnhance.Brightness(im).enhance(brightness)
    im = ImageEnhance.Contrast(im).enhance(contrast)
    im = ImageEnhance.Color(im).enhance(saturation)
    if warmth:
        a = np.asarray(im).astype(np.float32)
        a[...,0] = np.clip(a[...,0] + warmth*25, 0, 255)
        a[...,2] = np.clip(a[...,2] - warmth*18, 0, 255)
        im = Image.fromarray(a.astype(np.uint8), "RGB")
    W,H=size
    scale=max(W/im.width,H/im.height)*max(.01,zoom)
    nw,nh=max(W,int(im.width*scale)),max(H,int(im.height*scale))
    im=im.resize((nw,nh),Image.Resampling.LANCZOS)
    l=max(0,(nw-W)//2); t=max(0,(nh-H)//2)
    return im.crop((l,t,l+W,t+H))

def font(size, bold=True):
    candidates=[]
    wd=os.environ.get("WINDIR")
    if wd:
        candidates += [Path(wd)/"Fonts"/("arialbd.ttf" if bold else "arial.ttf"),
                       Path(wd)/"Fonts"/("segoeuib.ttf" if bold else "segoeui.ttf")]
    candidates += [Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold
                         else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")]
    for p in candidates:
        if p.exists(): return ImageFont.truetype(str(p),size)
    return ImageFont.load_default()

def caption_frame(im, text):
    if not text: return im
    d=ImageDraw.Draw(im,"RGBA"); W,H=im.size
    f=font(max(34,int(W*.052)),True)
    box=d.multiline_textbbox((0,0),text,font=f,align="center",spacing=8)
    tw,th=box[2]-box[0],box[3]-box[1]
    x=(W-tw)/2; y=H*.76; pad=25
    d.rounded_rectangle((x-pad,y-pad,x+tw+pad,y+th+pad),radius=20,fill=(0,0,0,155))
    d.multiline_text((x,y),text,font=f,fill="white",stroke_width=2,
                     stroke_fill=(0,0,0,180),align="center",spacing=8)
    return im

def render(project, output, progress=None, cancelled=None):
    if not project.slides: raise ValueError("Add at least one image.")
    music=ffprobe_duration(project.audio)
    if project.fit_music and music>0:
        durations=[music/len(project.slides)]*len(project.slides)
    else:
        durations=[max(.2,s.duration) for s in project.slides]
    total=sum(durations)
    fps=int(project.fps)
    # Crossfade is handled inside a single continuous frame stream.
    trans=project.transition_duration if project.transition=="Crossfade" else 0
    cache=[make_frame(s.path,SIZE,s.zoom,s.brightness,s.contrast,s.saturation,s.warmth)
           for s in project.slides]
    frames=max(1,int(math.ceil(total*fps)))
    tmp=Path(tempfile.mkstemp(suffix=".mp4")[1])
    try:
        # 1080x1920 is intentionally kept exact; macro_block_size=1 prevents 1088 resize.
        writer=imageio.get_writer(
            str(tmp), format="FFMPEG", mode="I", fps=fps,
            codec="libx264", pixelformat="yuv420p",
            macro_block_size=1, ffmpeg_log_level="error"
        )
        accs=[]; a=0
        for d in durations:
            accs.append(a); a+=d
        for n in range(frames):
            if cancelled and cancelled(): raise RuntimeError("Export cancelled")
            t=min(total-1e-7,n/fps)
            idx=len(durations)-1
            for i,start in enumerate(accs):
                if t < start+durations[i]:
                    idx=i; break
            local=t-accs[idx]
            frame=cache[idx].copy()
            if trans and idx>0 and local<trans:
                alpha=local/max(trans,.001)
                frame=Image.blend(cache[idx-1],frame,alpha)
            s=project.slides[idx]
            txt=s.caption or project.global_caption
            if s.effect=="Soft Blur": frame=frame.filter(ImageFilter.GaussianBlur(1.0))
            frame=caption_frame(frame,txt)
            writer.append_data(np.asarray(frame,dtype=np.uint8))
            if progress and (n % max(1,fps//2)==0): progress(int(n*100/frames))
        writer.close()
        if project.audio and Path(project.audio).exists():
            ff=imageio_ffmpeg.get_ffmpeg_exe()
            cmd=[ff,"-y","-i",str(tmp),"-i",str(project.audio),
                 "-map","0:v:0","-map","1:a:0","-c:v","copy","-c:a","aac",
                 "-b:a","192k","-shortest","-movflags","+faststart",str(output)]
            p=subprocess.run(cmd,capture_output=True,text=True)
            if p.returncode!=0:
                raise RuntimeError("FFmpeg audio mux failed:\n"+p.stderr[-4000:])
        else:
            Path(output).write_bytes(tmp.read_bytes())
        if progress: progress(100)
    finally:
        try: tmp.unlink(missing_ok=True)
        except: pass

def render_single(slide, output, fps=24, audio=""):
    p=Project(slides=[slide],audio=audio,fps=fps)
    render(p,output)
