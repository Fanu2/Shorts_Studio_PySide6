# Image Shape Studio v0.1

PySide6 + Pillow desktop app for masking images into 16 shapes.

Features: interactive drag, mouse-wheel zoom, rotation, output-size presets, transparent/solid background, border, soft shadow, PNG/JPEG/WEBP export, and batch conversion.

## Run on Windows

```powershell
python -m pip install -r requirements.txt
python -m image_shape_studio
```

No virtual environment is required.
