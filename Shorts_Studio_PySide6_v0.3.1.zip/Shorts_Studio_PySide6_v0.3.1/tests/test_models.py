from shorts_studio.models import Project, Slide
def test_defaults():
    p=Project([Slide("x.jpg")])
    assert p.width==1080 and p.height==1920
def test_roundtrip(tmp_path):
    p=Project([Slide("a.jpg",duration=5)],audio="song.mp3",fit_music=True)
    f=tmp_path/"p.ssp"; p.save(f); q=Project.load(f)
    assert q.slides[0].duration==5 and q.fit_music
