from PySide6.QtCore import QThread, Signal
class RenderWorker(QThread):
    progress=Signal(int)
    success=Signal(str)
    error=Signal(str)
    def __init__(self, fn, output):
        super().__init__(); self.fn=fn; self.output=output; self.stop=False
    def cancel(self): self.stop=True
    def run(self):
        try:
            self.fn(lambda x:self.progress.emit(x), lambda:self.stop)
            self.success.emit(str(self.output))
        except Exception as e: self.error.emit(str(e))
