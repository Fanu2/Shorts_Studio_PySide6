# Shorts Audio Cutter

A small offline PySide6 utility for cutting audio clips for YouTube Shorts.

## V0.1
- Open audio/video files supported by FFmpeg
- Generate and display a waveform
- Set start/end points
- Preview the selected section
- Export MP3 or WAV
- Quick 15/30/60/90 second selection

## Requirement
FFmpeg must be installed and available on PATH.

Run:
```bash
python -m pip install -r requirements.txt
python main.py
```
