# Shorts Studio v0.3

v0.3 restores the richer v0.1-style dashboard and fixes the combined MP4 pipeline.

## Run
```powershell
cd "C:\Users\singh\Downloads\Shorts_Studio_PySide6_v0.3\Shorts_Studio_PySide6_v0.3"
python -m pip install -r requirements.txt
python -m shorts_studio
```

No virtual environment is required.

## Export
**Export ONE MP4** always creates one combined slideshow video.
Output is exactly **1080 x 1920**, H.264, yuv420p. The renderer uses macro_block_size=1 so imageio does not resize 1080 to 1088.

## Editing
- storyboard/reorder/delete
- live 9:16 preview
- play/pause preview
- per-image duration
- crossfade
- music
- fit images to music
- captions
- zoom and image adjustments
- save/open .ssp

## v0.3.1 fixes

- Fixed Windows audio duration detection: no `get_ffprobe_exe()` call.
- Uses the bundled FFmpeg executable to read audio duration.
- Reduced the preview's minimum geometry so the application fits normal Windows displays.
- Combined MP4 export remains the primary export.
